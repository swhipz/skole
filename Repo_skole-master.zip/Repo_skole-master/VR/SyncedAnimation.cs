public animator animator;

public AnimatorStateInfo animatorStateInfo;

public int currentState;

